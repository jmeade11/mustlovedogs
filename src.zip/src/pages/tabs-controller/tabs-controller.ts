import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { FilterPage } from '../filter/filter';
import { ProfilePage } from '../profile/profile';
import { MatchesPage } from '../matches/matches';
import { MessagesPage } from '../messages/messages';

@Component({
  selector: 'page-tabs-controller',
  templateUrl: 'tabs-controller.html'
})
export class TabsControllerPage {
  // this tells the tabs component which Pages
  // should be each tab's root Page
  tab1Root: any = FilterPage;
  tab2Root: any = MatchesPage;
  tab3Root: any = MessagesPage;
  tab4Root: any = ProfilePage;
  constructor(public navCtrl: NavController) {
  }
  goToFilter(params){
    if (!params) params = {};
    this.navCtrl.push(FilterPage);
  }goToProfile(params){
    if (!params) params = {};
    this.navCtrl.push(ProfilePage);
  }goToMatches(params){
    if (!params) params = {};
    this.navCtrl.push(MatchesPage);
  }goToMessages(params){
    if (!params) params = {};
    this.navCtrl.push(MessagesPage);
  }
}
